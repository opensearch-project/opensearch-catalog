from .__main__ import cli_detect, query_yes_no

__all__ = (
    "cli_detect",
    "query_yes_no",
)
